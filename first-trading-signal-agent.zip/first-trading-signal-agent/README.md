# First Trading Signal Agent

A paper-trading signal engine that classifies market conditions as:

- `BUY`
- `SELL`
- `HOLD`
- `NO_TRADE`

It calculates EMA, RSI, MACD, ATR, volume confirmation, stop-loss, take-profit,
risk/reward, confidence, and position size.

> Educational software only. It is not financial advice and does not place live trades.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py --symbol SPY --period 6mo --interval 1d
```

## Run tests

```bash
pytest
```

## How decisions work

A trade is blocked when data is insufficient, volatility is excessive, volume is weak,
or the expected reward-to-risk ratio is below the configured minimum.

Signals are generated from:

- Fast and slow EMA trend
- RSI momentum
- MACD confirmation
- Relative volume
- ATR-based risk levels

Configuration is in `config.py`.
