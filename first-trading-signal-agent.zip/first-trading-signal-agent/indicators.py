import numpy as np
import pandas as pd

from config import StrategyConfig


def add_indicators(data: pd.DataFrame, cfg: StrategyConfig) -> pd.DataFrame:
    required = {"Open", "High", "Low", "Close", "Volume"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    df = data.copy()
    close = df["Close"].astype(float)

    df["ema_fast"] = close.ewm(span=cfg.fast_ema, adjust=False).mean()
    df["ema_slow"] = close.ewm(span=cfg.slow_ema, adjust=False).mean()

    delta = close.diff()
    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)
    avg_gain = gains.ewm(alpha=1 / cfg.rsi_period, adjust=False).mean()
    avg_loss = losses.ewm(alpha=1 / cfg.rsi_period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    df["rsi"] = (100 - (100 / (1 + rs))).fillna(50)

    macd = df["ema_fast"] - df["ema_slow"]
    df["macd"] = macd
    df["macd_signal"] = macd.ewm(span=cfg.macd_signal, adjust=False).mean()
    df["macd_hist"] = df["macd"] - df["macd_signal"]

    previous_close = close.shift(1)
    true_range = pd.concat(
        [
            df["High"] - df["Low"],
            (df["High"] - previous_close).abs(),
            (df["Low"] - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    df["atr"] = true_range.ewm(alpha=1 / cfg.atr_period, adjust=False).mean()
    df["atr_percent"] = (df["atr"] / close) * 100

    df["avg_volume"] = df["Volume"].rolling(cfg.volume_period).mean()
    df["relative_volume"] = df["Volume"] / df["avg_volume"].replace(0, np.nan)

    return df
