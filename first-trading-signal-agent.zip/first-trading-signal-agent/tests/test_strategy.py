import numpy as np
import pandas as pd

from config import StrategyConfig
from indicators import add_indicators
from strategy import evaluate


def sample_data(rows: int = 100) -> pd.DataFrame:
    close = np.linspace(100, 130, rows)
    return pd.DataFrame(
        {
            "Open": close - 0.5,
            "High": close + 1,
            "Low": close - 1,
            "Close": close,
            "Volume": np.full(rows, 1_000_000),
        }
    )


def test_indicators_are_added() -> None:
    cfg = StrategyConfig()
    enriched = add_indicators(sample_data(), cfg)
    for column in [
        "ema_fast", "ema_slow", "rsi", "macd", "macd_signal",
        "macd_hist", "atr", "atr_percent", "relative_volume",
    ]:
        assert column in enriched.columns


def test_strategy_returns_valid_action() -> None:
    cfg = StrategyConfig(min_relative_volume=0.5)
    enriched = add_indicators(sample_data(), cfg)
    signal = evaluate("TEST", enriched, cfg)
    assert signal.action in {"BUY", "SELL", "HOLD", "NO_TRADE"}
    assert 0 <= signal.confidence <= 100
