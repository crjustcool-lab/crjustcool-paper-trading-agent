from dataclasses import asdict, dataclass
from typing import Literal

Action = Literal["BUY", "SELL", "HOLD", "NO_TRADE"]


@dataclass(frozen=True)
class TradeSignal:
    symbol: str
    action: Action
    price: float
    stop_loss: float | None
    take_profit: float | None
    risk_reward: float | None
    confidence: int
    position_size: int
    reasons: list[str]

    def to_dict(self) -> dict:
        return asdict(self)
