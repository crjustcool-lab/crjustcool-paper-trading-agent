from dataclasses import dataclass


@dataclass(frozen=True)
class StrategyConfig:
    fast_ema: int = 12
    slow_ema: int = 26
    rsi_period: int = 14
    macd_signal: int = 9
    atr_period: int = 14
    volume_period: int = 20

    rsi_buy_min: float = 45.0
    rsi_buy_max: float = 70.0
    rsi_sell_min: float = 30.0
    rsi_sell_max: float = 55.0

    min_relative_volume: float = 0.85
    max_atr_percent: float = 6.0
    stop_atr_multiple: float = 1.5
    target_atr_multiple: float = 3.0
    min_risk_reward: float = 1.8
    min_confidence: int = 60

    account_size: float = 10_000.0
    risk_per_trade: float = 0.01
    max_position_percent: float = 0.20
