import math
import pandas as pd

from config import StrategyConfig
from models import TradeSignal


def _position_size(price: float, stop: float, cfg: StrategyConfig) -> int:
    risk_per_share = abs(price - stop)
    if risk_per_share <= 0:
        return 0

    risk_budget = cfg.account_size * cfg.risk_per_trade
    risk_limited = math.floor(risk_budget / risk_per_share)
    capital_limited = math.floor(
        (cfg.account_size * cfg.max_position_percent) / price
    )
    return max(0, min(risk_limited, capital_limited))


def evaluate(symbol: str, df: pd.DataFrame, cfg: StrategyConfig) -> TradeSignal:
    minimum_rows = max(cfg.slow_ema, cfg.volume_period, cfg.atr_period) + 5
    if len(df) < minimum_rows:
        return TradeSignal(
            symbol, "NO_TRADE", 0.0, None, None, None, 0, 0,
            [f"Insufficient history: need at least {minimum_rows} rows"],
        )

    row = df.iloc[-1]
    previous = df.iloc[-2]
    price = float(row["Close"])
    atr = float(row["atr"])
    rsi = float(row["rsi"])
    relative_volume = float(row["relative_volume"])
    atr_percent = float(row["atr_percent"])

    if any(pd.isna(v) for v in [price, atr, rsi, relative_volume, atr_percent]):
        return TradeSignal(
            symbol, "NO_TRADE", price, None, None, None, 0, 0,
            ["Latest indicators contain missing values"],
        )

    no_trade_reasons: list[str] = []
    if atr_percent > cfg.max_atr_percent:
        no_trade_reasons.append(
            f"Volatility too high: ATR is {atr_percent:.2f}% of price"
        )
    if relative_volume < cfg.min_relative_volume:
        no_trade_reasons.append(
            f"Volume too weak: relative volume is {relative_volume:.2f}"
        )

    bullish = [
        row["ema_fast"] > row["ema_slow"],
        row["macd"] > row["macd_signal"],
        row["macd_hist"] > previous["macd_hist"],
        cfg.rsi_buy_min <= rsi <= cfg.rsi_buy_max,
        relative_volume >= 1.0,
        price > row["ema_fast"],
    ]
    bearish = [
        row["ema_fast"] < row["ema_slow"],
        row["macd"] < row["macd_signal"],
        row["macd_hist"] < previous["macd_hist"],
        cfg.rsi_sell_min <= rsi <= cfg.rsi_sell_max,
        relative_volume >= 1.0,
        price < row["ema_fast"],
    ]

    bull_score = sum(bool(x) for x in bullish)
    bear_score = sum(bool(x) for x in bearish)

    if no_trade_reasons:
        return TradeSignal(
            symbol, "NO_TRADE", round(price, 2), None, None, None,
            max(bull_score, bear_score) * 100 // 6, 0, no_trade_reasons,
        )

    if bull_score >= 4 and bull_score > bear_score:
        action = "BUY"
        stop = price - cfg.stop_atr_multiple * atr
        target = price + cfg.target_atr_multiple * atr
        reasons = [
            "Fast EMA is above slow EMA" if bullish[0] else "EMA trend not confirmed",
            "MACD is bullish" if bullish[1] else "MACD is not bullish",
            f"RSI is {rsi:.1f}",
            f"Relative volume is {relative_volume:.2f}",
        ]
        confidence = round(bull_score / 6 * 100)
    elif bear_score >= 4 and bear_score > bull_score:
        action = "SELL"
        stop = price + cfg.stop_atr_multiple * atr
        target = price - cfg.target_atr_multiple * atr
        reasons = [
            "Fast EMA is below slow EMA" if bearish[0] else "EMA trend not confirmed",
            "MACD is bearish" if bearish[1] else "MACD is not bearish",
            f"RSI is {rsi:.1f}",
            f"Relative volume is {relative_volume:.2f}",
        ]
        confidence = round(bear_score / 6 * 100)
    else:
        return TradeSignal(
            symbol, "HOLD", round(price, 2), None, None, None,
            round(max(bull_score, bear_score) / 6 * 100), 0,
            ["No sufficiently strong directional setup"],
        )

    risk = abs(price - stop)
    reward = abs(target - price)
    risk_reward = reward / risk if risk else 0.0

    if risk_reward < cfg.min_risk_reward or confidence < cfg.min_confidence:
        return TradeSignal(
            symbol, "NO_TRADE", round(price, 2), round(stop, 2),
            round(target, 2), round(risk_reward, 2), confidence, 0,
            reasons + ["Setup failed minimum quality threshold"],
        )

    return TradeSignal(
        symbol=symbol,
        action=action,
        price=round(price, 2),
        stop_loss=round(stop, 2),
        take_profit=round(target, 2),
        risk_reward=round(risk_reward, 2),
        confidence=confidence,
        position_size=_position_size(price, stop, cfg),
        reasons=reasons,
    )
