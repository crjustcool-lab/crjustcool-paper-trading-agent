from dataclasses import dataclass

from models import TradeSignal


@dataclass
class PaperPosition:
    symbol: str
    side: str
    quantity: int
    entry_price: float
    stop_loss: float
    take_profit: float


class PaperTrader:
    def __init__(self, starting_cash: float = 10_000.0) -> None:
        self.cash = starting_cash
        self.positions: dict[str, PaperPosition] = {}

    def open_from_signal(self, signal: TradeSignal) -> PaperPosition | None:
        if signal.action not in {"BUY", "SELL"}:
            return None
        if not signal.stop_loss or not signal.take_profit or signal.position_size <= 0:
            return None
        if signal.symbol in self.positions:
            return None

        position = PaperPosition(
            symbol=signal.symbol,
            side=signal.action,
            quantity=signal.position_size,
            entry_price=signal.price,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
        )
        self.positions[signal.symbol] = position
        return position

    def evaluate_exit(self, symbol: str, market_price: float) -> str | None:
        position = self.positions.get(symbol)
        if not position:
            return None

        if position.side == "BUY":
            if market_price <= position.stop_loss:
                return "STOP_LOSS"
            if market_price >= position.take_profit:
                return "TAKE_PROFIT"
        else:
            if market_price >= position.stop_loss:
                return "STOP_LOSS"
            if market_price <= position.take_profit:
                return "TAKE_PROFIT"

        return "HOLD"
