import argparse
import json

from config import StrategyConfig
from data_provider import download_market_data
from indicators import add_indicators
from strategy import evaluate


def main() -> None:
    parser = argparse.ArgumentParser(description="Paper trading signal agent")
    parser.add_argument("--symbol", default="SPY")
    parser.add_argument("--period", default="6mo")
    parser.add_argument("--interval", default="1d")
    args = parser.parse_args()

    cfg = StrategyConfig()
    raw = download_market_data(args.symbol, args.period, args.interval)
    enriched = add_indicators(raw, cfg)
    signal = evaluate(args.symbol.upper(), enriched, cfg)
    print(json.dumps(signal.to_dict(), indent=2))


if __name__ == "__main__":
    main()
